#include "\DZ\data\basicDefines.hpp"

class CfgPatches
{
	class DZ_Worlds_Sakhal_CE
	{
		units[] = {};
		weapons[] = {};
		requiredVersion = 0.1;
		requiredAddons[] = {"DZ_Data"};
	};
};